﻿using System;
using Moq;
using NUnit.Framework;
using TDDMicroExercises.TirePressureMonitoringSystem;

namespace TirePressureTests
{
    public class AlarmTests
    {


        [Test]
        [TestCase(16)]
        public void AlarmActivatesOnPressureValueOutsideOfTheBoundries(int returnCase)
        {
            Mock<Sensor> sensor = new Mock<Sensor>();
            sensor.Setup(x => x.PopNextPressurePsiValue()).Returns(20.0);
            Mock<Alarm> alarm = new Mock<Alarm>(sensor);
            alarm.Setup(x => x.Check());
            alarm.Setup(x => x.AlarmOn);
            

           Assert.That(()=>alarm.Object.AlarmOn,Is.EqualTo(true));
        }
    }
}
