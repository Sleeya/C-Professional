﻿using System.Collections.Generic;

public interface IEngineer
{
    List<string> Repairs { get; set; }
}
