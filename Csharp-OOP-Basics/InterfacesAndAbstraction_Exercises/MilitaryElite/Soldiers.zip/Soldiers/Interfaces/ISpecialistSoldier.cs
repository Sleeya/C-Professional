﻿public interface ISpecialistSoldier
{
    string Corps { get; set; }
}

